<?php 
header("Content-type:text/css")
 ?>

 .div1{
background-color: darkgreen;
height: 100vh;
width: 100vw;

}

#heading{
    color: greenyellow;
    font-size: 40pt;
    padding-bottom: 0px;
    padding-left: 330px;
}

.div2{
    background-image: url(../img/pitch.jpg);
    height: 500px;
  width: 1000px;
margin-left: 150px;
margin-right: 150px;
background-repeat: no-repeat;
background-position: center;
}

.div3{
    background-image: url(../img/pitch_white.jpg);
    margin-top: 0px;
    height: 520px;
  width: 1000px;
margin-left: 150px;
margin-right: 150px;
background-repeat: no-repeat;
background-position: center;
}

.paragraphs{
display: inline-block;
    padding-top: 470px;
    padding-left: 280px;
    font-family: Tahoma, Geneva, sans-serif;
    text-align: center;
}

.paragraphs_player{
display: inline-block;
    padding-top: 450px;
    padding-left: 250px;
    font-family: Tahoma, Geneva, sans-serif;
    text-align: center;
}

.paragraphs_manager{
display: inline-block;
    padding-top: 450px;
    padding-left: 100px;
    font-family: Tahoma, Geneva, sans-serif;
    text-align: center;
}

.tags{
    color: greenyellow;
    text-decoration: none;
    font-size: 20pt;
}
.tags_player{
    color: darkblue;
    text-decoration: none;
    font-size: 20pt;
}

a:hover{
    color: darkred;
}

h4{


}  
