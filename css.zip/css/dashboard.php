<?php 
header("Content-type:text/css")
 ?>

.bg-custom-1 {
  background-color: #85144b;
}

.bg-custom-2 {
background-image: linear-gradient(15deg, #13547a 0%, #80d0c7 100%);
}


table {
width-top:20px;
  border-collapse: collapse;
  width: 100%;
}
th, td {
  border: 1px solid black;
  width:10%;
}
.roww {
  display: flex;
}

.columnn {
  flex: 50%;
}
.box{

margin-bottom: 10px;
width: 15%;

}
.label{
margin-left: 10px;
width:150px;
}
.labell{
margin-left: 10px;
margin-bottom: 10px;
width:100px;
}
.button{
  background-color:darkblue;
  color:white;
  margin-left:40%;
  height:50px;
  width:150px;
    font-size: 20pt;
        font-family: Tahoma, Geneva, sans-serif;
}