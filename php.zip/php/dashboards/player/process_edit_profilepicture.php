<?php
include_once '../../database_connections/general_connection.php';
$link = connect();
session_start();
$username = $_SESSION["username"];

if (isset($_POST["updateprofilepicture"])){

if (isset($_FILES["profile_image"])) {
$profile_image = $_FILES["profile_image"];
$original_file_name = $_FILES["profile_image"]["name"];
$file_tmp_location = $_FILES["profile_image"]["tmp_name"];


$file_type = substr($original_file_name,strpos($original_file_name,'.'),strlen(
  $original_file_name));

$file_path = "../../../assets/";

$new_file_name = time().$file_type;
$new_name =  $file_path.$new_file_name;
if (move_uploaded_file($file_tmp_location, $file_path.$new_file_name)){

$sql ="UPDATE tbluserdetails SET imageoriginalname='$original_file_name', imagepathname='$new_name' WHERE username= '$username'"; 
$result = mysqli_query($link, $sql);
}
}
}

else {
 echo "Error updating record: " . mysqli_error($conn);
}
header("location:player.php");
?>