<!DOCTYPE html>
<html>
 <head>
 <title>Edit user Profiles</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="../../../css/edit_profile.php">





</head>
<body>
<div class="wrapper bg-white mt-sm-5">
    <h4 class="pb-4 border-bottom">Account settings</h4>
    <div class="d-flex align-items-start py-3 border-bottom"> <img src="https://images.pexels.com/photos/1037995/pexels-photo-1037995.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500" class="img" alt="">
<form name="edit" action = "process_edit_profilepicture.php" method="post" enctype="multipart/form-data" onload="EnableDisable()">
        <div class="pl-sm-4 pl-2" id="img-section"> <b>Profile Photo</b>
            <p>Accepted file type .png. Less than 1MB</p> <input type="file" name="profile_image" id="profile_image"class="btn button border">
        </div>
        <br>
         <input type="submit" name="updateprofilepicture" value="Save Profile Picture" id="update">
    </div>

    </form>
<form name="edit" action = "process_edit_profile.php" method="get" enctype="multipart/form-data" > 
    <div class="py-2">
        <div class="row py-2">
            <div class="col-md-6"> <label for="username">Username</label> <input type="text" name="username" id="username" class="bg-light form-control" >
            </div>
            <div class="col-md-6 pt-md-0 pt-3"> <label for="password">Password</label> <input type="password"  name="password" id="password" class="bg-light form-control"> </div>
        </div>
      
  
<input type="submit" name="updateusername" value="Save Username" id="update">  
<input type="submit" name="updatepassword" value="Save Password" id="update">


<a href="manager.php">Cancel</a>
         </div>
       
    </div>
    </form>

</div>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>
</html>