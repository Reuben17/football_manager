<?php

include('../../database_connections/login_connection.php');
require_once("../../database_connections/general_connection.php");
$username =$_SESSION["username"];
$link = connect();
$sql = "SELECT imagepathname FROM tbluserdetails WHERE username ='$username'";
$result =mysqli_query($link,$sql);
$sql1 = "SELECT * FROM tbluserdetails WHERE role ='Manager'";
$result1 =mysqli_query($link,$sql1);
$sql2 = "SELECT * FROM tbluserdetails WHERE role ='Player'";
$result2 =mysqli_query($link,$sql2);


if(!isset($_SESSION['username'])) {
header("Location:../../../index.php"); 
} 

?>

<!DOCTYPE html>
<html>
 <head>
 <title>View All User Details</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="../../../css/dashboard.php">




</head>
<body>

<nav class="navbar navbar-dark bg-dark navbar-expand-sm">
  <p class="navbar-brand" href="#">
Welcome <?php echo $_SESSION["username"];?>
  </p>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-list-4" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbar-list-4">
    <ul class="navbar-nav">
        <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <img 

<?php
$i=0;
while($row = mysqli_fetch_array($result)) { 
?>
 src="<?php echo $row["imagepathname"]; ?>" width="100" height="100" class="rounded-circle" >
<?php
$i++;
}
?>

        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="edit_profile.php">Edit Profile</a>
          <a class="dropdown-item" href="../../database_connections/login_connection.php?logout_user">Log Out</a>
        </div>
      </li>   
    </ul>
  </div>
</nav>


<?php 

if (mysqli_num_rows($result1) > 0) {
?>
  <table class="table table-dark">
  <br>
  <thead>
     <th>ID</th>
    <th>First Name</th>
    <th>Last Name</th>
    <th>Username</th>
    <th>Email</th>
    <th>Role</th>
    <th>Position</th>
  </thead>
<?php
$i=0;
while($row = mysqli_fetch_array($result1)) {
?>
<tr>
    <td><?php echo $row["id"]; ?></td>
    <td><?php echo $row["first_name"]; ?></td>
    <td><?php echo $row["last_name"]; ?></td>
    <td><?php echo $row["username"]; ?></td>
    <td><?php echo $row["email"]; ?></td>
     <td><?php echo $row["role"]; ?></td>
      <td><?php echo $row["position"]; ?></td>
</tr>
<?php
$i++;
}
?>
</table>
 <?php
}
else{
    echo "No result found";
}
?>

<?php 

if (mysqli_num_rows($result2) > 0) {
?>
  <table class="table table-dark">
  <br>
  <thead>
     <th>ID</th>
    <th>First Name</th>
    <th>Last Name</th>
    <th>Username</th>
    <th>Email</th>
    <th>Role</th>
    <th>Position</th>
  </thead>
<?php
$i=0;
while($row = mysqli_fetch_array($result2)) {
?>
<tr>
    <td><?php echo $row["id"]; ?></td>
    <td><?php echo $row["first_name"]; ?></td>
    <td><?php echo $row["last_name"]; ?></td>
    <td><?php echo $row["username"]; ?></td>
    <td><?php echo $row["email"]; ?></td>
     <td><?php echo $row["role"]; ?></td>
      <td><?php echo $row["position"]; ?></td>
</tr>
<?php
$i++;
}
?>
</table>
 <?php
}
else{
    echo "No result found";
}
?>



<form action = "updateplayerposition.php" method="post">
<label for="id">Insert Position:</label>
<select list="id" name="id">
<datalist id="id">
<option value= "--">--</option>
<?php
$i=0;
$sql2 = "SELECT * FROM tbluserdetails WHERE role ='Player'";
$result2 =mysqli_query($link,$sql2);
while($row = mysqli_fetch_array($result2)) {
?>
<option value= "<?php echo $row["id"]?>"><?php echo $row["id"]."   ".$row["first_name"]." ".$row["last_name"]?></option>
<?php
$i++;
}
?>
</datalist>
</select>  
<input type="submit" name="update" value="submit" id="submit">

</form>
<br>
<form action = "process_delete.php" method="post">
<label for="id">Delete Record (Input ID):</label>
<br>
<input type="text" name="id" id="id">
<input type="submit" name="delete" value="submit" id="submit">
</form>
<br>
<Label>Insert player attendance and statistics</label>


<form name="regform" action = "process_update_attendance_and_statistics.php" method="post" onsubmit="validateForm()" class="form-inline">
 <div class="form-group">
 
<label for="year" class="labell">Year:</label>
 <select list="year" name="year">
  <datalist id="year">
<option value="2021">2021</option>
<option value="2022">2022</option> 
<option value="2023">2023</option> 
</datalist>
</select>

<label for="month" class="labell">Month:</label>
 <select list="month" name="month">
  <datalist id="month">
<option value="January">January</option>  
<option value="February">February</option> 
<option value="March">March</option>
<option value="April">April</option>
<option value="May">May</option> 
<option value="June">June</option> 
<option value="July">July</option> 
<option value="August">August</option> 
<option value="September">September</option>
<option value="October">October</option> 
<option value="November">November</option> 
<option value="December">December</option>
</datalist>
</select> 

<label for="week" class="labell">Week:</label>
 <select list="week" name="week">
  <datalist id="week">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>     
</datalist>
</select>


<br>
<label for="id" class="labell">Player Id:</label>
  <select list="id" name="id">
  <datalist id="id">
<option value= "--">--</option>
    <?php
$sql2 = "SELECT * FROM tbluserdetails WHERE role ='Player'";
$result2 =mysqli_query($link,$sql2);
$i=0;
while($row = mysqli_fetch_array($result2)) {
?>
<option value="<?php echo $row["id"]; ?>"><?php echo $row["id"]."   ".$row["first_name"]." ".$row["last_name"]; ?></option>   
<?php
$i++;
}
?>
</datalist>
</select>

<br>  
<label for="monday" class="labell">Monday:</label>
 <select list="monday" name="monday">
<datalist id="monday">
<option value="Present">Present</option> 
<option value="Absent">Absent</option> 
</datalist>
</select>
<br>
<label for="tuesday" class="labell">Tuesday:</label>
 <select list="tuesday" name="tuesday">
<datalist id="tuesday">
<option value="Present">Present</option> 
<option value="Absent">Absent</option>
</datalist>
</select>
<br>
<label for="wednesday" class="labell">Wednesday:</label>
 <select list="wednesday" name="wednesday">
<datalist id="wednesday">
<option value="Present">Present</option> 
<option value="Absent">Absent</option>
</datalist>
</select>
<br>
<label for="thursday" class="labell">Thursday:</label>
 <select list="thursday" name="thursday">
<datalist id="thursday">
<option value="Present">Present</option> 
<option value="Absent">Absent</option> 
</datalist>
</select>
<br>
<label for="friday" class="labell">Friday:</label>
 <select list="friday" name="friday">
<datalist id="friday">
<option value="Present">Present</option>
<option value="Absent">Absent</option> 
</datalist>
</select>
<br>
<br>

<label for="saves" class="label">Saves:</label>
<input type="text" name="saves" id="saves" class="box"> 

<label for="complete_passes" class="label">Complete Passes:</label>
<input type="text" name="complete_passes" id="complete_passes" class="box">

<label for="successful_tackles" class="label">Successful Tackles:</label>
<input type="text" name="successful_tackles" id="successful_tackles" class="box">
<br>   
<label for="clearances" class="label">Clearances:</label>
<input type="text" name="clearances" id="clearances" class="box">

<label for="successful_crosses" class="label">Successful Crosses:</label>
<input type="text" name="successful_crosses" id="successful_crosses" class="box">
 
<label for="attacks_destroyed" class="label">Attacks Destroyed:</label>
<input type="text" name="attacks_destroyed" id="attacks_destroyed" class="box">
<br> 
<label for="chances_created" class="label">Chances Created:</label>
<input type="text" name="chances_created" id="chances_created" class="box">

<label for="assists" class="label">Assists:</label>
<input type="text" name="assists" id="assists" class="box">

<label for="goals" class="label">Goals:</label>
<input type="text" name="goals" id="goals" class="box">
<br>   
<br>
<button type="submit" name="submit" value="submit" id="submit" class="button">Submit</button>
</form>





<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

 </body>
</html>