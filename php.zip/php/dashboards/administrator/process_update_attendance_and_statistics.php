<?php
require_once("../../database_connections/general_connection.php");

if (isset($_POST["submit"])){
session_start();
$year=$_POST["year"];
$month=$_POST["month"];
$week =$_POST["week"];
$id = $_POST["id"];

if ($_POST["monday"]== "Present"){
$monday = 1;
} else {
$monday = 0;    
}

if ($_POST["tuesday"]== "Present"){
$tuesday = 1;
} else {
$tuesday = 0;    
}

if ($_POST["wednesday"]== "Present"){
$wednesday = 1;
} else {
$wednesday = 0;    
}

if ($_POST["thursday"]== "Present"){
$thursday = 1;
} else {
$thursday = 0;    
}

if ($_POST["friday"]== "Present"){
$friday = 1;
} else {
$friday = 0;    
}
$total = $monday + $tuesday + $wednesday + $thursday + $friday;

$saves =$_POST["saves"];
$complete_passes =$_POST["complete_passes"];
$successful_tackles =$_POST["successful_tackles"];
$clearances =$_POST["clearances"];
$successful_crosses =$_POST["successful_crosses"];
$attacks_destroyed =$_POST["attacks_destroyed"];
$chances_created =$_POST["chances_created"];
$assists =$_POST["assists"];
$goals =$_POST["goals"];

$sql1 = "INSERT INTO tblattendance(year, month, week, id, monday, tuesday, wednesday, 
thursday, friday, total)VALUES('$year','$month','$week','$id','$monday','$tuesday',
'$wednesday','$thursday','$friday', '$total')";

$sql2 = "INSERT INTO tblstatistics(year, month, week, id, saves, complete_passes,successful_tackles, clearances, 
successful_crosses, attacks_destroyed, chances_created, assists, goals, total)
VALUES('$year','$month','$week','$id','$saves','$complete_passes','$successful_tackles','$clearances',
'$successful_crosses','$attacks_destroyed','$chances_created','$assists','$goals','$total')";

echo setData($sql1);
echo setData($sql2);
 header("location:administrator.php");

}
?>