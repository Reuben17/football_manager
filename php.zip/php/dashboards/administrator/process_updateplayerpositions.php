<?php
include_once '../../database_connections/general_connection.php';
$link = connect();

session_start();
$id = $_SESSION["id"];
$position =$_POST["position"];

$sql ="UPDATE tbluserdetails SET position='$position' WHERE id='$id'";

if (mysqli_query($link, $sql)) {
  echo "Record updated successfully";
} else {
  echo "Error updating record: " . mysqli_error($conn);
}
header("location:administrator.php");

?>