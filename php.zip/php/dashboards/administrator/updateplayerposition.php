<html>
<head>
<title>Update Details For Havana Users</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="../../../css/dashboard.php">
<?php
if (isset($_POST["update"])){
session_start();
$_SESSION["id"] = $_POST["id"];
$id = $_SESSION["id"];
}
?>
</head>
<body>
<form action="process_updateplayerpositions.php" method="post">
<br>	
<label for="position">Position:</label>
  <select list="position" name="position">
  <datalist id="position">
<option value="--">--</option>
<option value="Goalkeeper">Goalkeeper</option>
<option value="Centre Back">Centre Back</option>
<option value="Right Back">Right Back</option>
<option value="Left Back">Left Back</option>
<option value="Defensive Midfielder">Defensive Midfielder</option>
<option value="Attacking Midfielder">Attacking Midfielder</option>
<option value="Left Midfielder">Left Midfielder</option>
<option value="Right Midfielder">Right Midfielder</option>
<option value="Left Wing">Left Wing</option>
<option value="Right Wing">Right Wing</option>
<option value="Striker">Striker</option>
</datalist>
</select>
<input type="submit" name="update" value="update" id="update">
<br>
</form>
</div>




<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>