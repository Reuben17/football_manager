<?php

include('../../database_connections/login_connection.php');
require_once("../../database_connections/general_connection.php");
$username =$_SESSION["username"];
$link = connect();
$sql = "SELECT imagepathname FROM tbluserdetails WHERE username ='$username'";
$result =mysqli_query($link,$sql);


if(!isset($_SESSION['username'])) {
header("Location:../../../index.php"); 
} 

?>

<!DOCTYPE html>
<html>
 <head>
 <title>View All User Details</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="../../../css/dashboard.php">
<link rel="stylesheet" type="text/css" href="../../../css/index.php">



</head>
<body>

<nav class="navbar navbar-dark bg-dark navbar-expand-sm">
  <p class="navbar-brand" href="#">
Welcome <?php echo $_SESSION["username"];?>
  </p>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-list-4" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbar-list-4">
    <ul class="navbar-nav">
        <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <img 

<?php
$i=0;
while($row = mysqli_fetch_array($result)) { 
?>
 src="<?php echo $row["imagepathname"]; ?>" width="100" height="100" class="rounded-circle" >
<?php
$i++;
}
?>

        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="edit_profile.php">Edit Profile</a>
          <a class="dropdown-item" href="../../database_connections/login_connection.php?logout_user">Log Out</a>
        </div>
      </li>   
    </ul>
  </div>
</nav>

<div class="div3"> 

 <p class="paragraphs_manager"><a  class="tags_player" href="statistics.php">Squad Statistics</a></p>
<p class="paragraphs_manager"><a  class="tags_player" href="squad.php">Matchday Squad</a></p>
 <p class="paragraphs_manager"><a  class="tags_player" href=attendance.php>Squad Attendance</a></p>
</div>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

 </body>
</html>