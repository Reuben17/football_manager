<?php

include('../../database_connections/login_connection.php');
require_once("../../database_connections/general_connection.php");
$username =$_SESSION["username"];
$link = connect();
$sql = "SELECT imagepathname FROM tbluserdetails WHERE username ='$username'";
$result =mysqli_query($link,$sql);


if(!isset($_SESSION['username'])) {
header("Location:../../authentication_module/login.php"); 
} 

?>

<!DOCTYPE html>
<html>
 <head>
 <title>View All User Details</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="../../../css/dashboard.php">
<link rel="stylesheet" type="text/css" href="../../../css/index.php">

</head>
<body>

<nav class="navbar navbar-dark bg-dark navbar-expand-sm">
  <p class="navbar-brand" href="#">
<?php echo $_SESSION["username"];?>
  </p>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-list-4" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbar-list-4">
    <ul class="navbar-nav">
        <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <img 

<?php
$i=0;
while($row = mysqli_fetch_array($result)) { 
?>
 src="<?php echo $row["imagepathname"]; ?>" width="100" height="100" class="rounded-circle" >
<?php
$i++;
}
?>

        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="manager.php">Dashboard</a>
          <a class="dropdown-item" href="../../database_connections/login_connection.php?logout_user">Log Out</a>
        </div>
      </li>   
    </ul>
  </div>
</nav>

<h1>Select Date</h1>
<form name="regform" action = "statistics.php" method="post" onsubmit="validateForm()">
<label for="year">Year:</label>
  <select list="year" name="year">
  <datalist id="year">
<option value="2021">2021</option>
<option value="2022">2022</option> 
<option value="2023">2023</option> 
</datalist>
</select>

<label for="year">Month:</label>
  <select list="month" name="month">
  <datalist id="month">
 <option value="January">January</option>  
<option value="February">February</option> 
<option value="March">March</option>
<option value="April">April</option>
<option value="May">May</option> 
<option value="June">June</option> 
<option value="July">July</option> 
<option value="August">August</option> 
<option value="September">September</option>
<option value="October">October</option> 
<option value="November">November</option> 
<option value="December">December</option>
</datalist>
</select>

<label for="week">week:</label>
  <select list="week" name="week">
  <datalist id="week">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option> 
</datalist>
</select>

<button type="submit" name="submit" value="submit" id="submit">Submit</button>
<br>
<br>
</form>

<?php 
if (isset($_POST["submit"])){
$username =$_SESSION["username"];
$year =$_POST["year"];
$month =$_POST["month"];
$week =$_POST["week"];

$sql1 = "SELECT * FROM tblstatistics WHERE year = $year AND month ='$month' AND week = $week";

$result1 =mysqli_query($link,$sql1);



if (mysqli_num_rows($result1) > 0) {
?>
  <table class="table table-dark">
  <br>
  <thead>
    <th>First Name</th>
    <th>Last Name</th>
     <th>Saves</th>
    <th>Complete Passes</th>
    <th>Successful Tackles</th>
    <th>Clearances</th>
    <th>Successful Crosses</th>
    <th>Attacks Destroyed</th>
    <th>Chances Created</th>
    <th>Assists</th>
    <th>Goals</th>
  </thead>
<?php
$i=2;
while($row = mysqli_fetch_array($result1)  ){
$sql2 = "SELECT * FROM tbluserdetails WHERE id =$i";
 $result2 =mysqli_query($link,$sql2);
 $roww =mysqli_fetch_array($result2);
 $i+1;
?>
<tr>
  <td><?php echo $roww["first_name"]; ?></td>
  <td><?php echo $roww["last_name"]; ?></td>
    <td><?php echo $row["saves"]; ?></td>
    <td><?php echo $row["complete_passes"]; ?></td>
    <td><?php echo $row["successful_tackles"]; ?></td>
    <td><?php echo $row["clearances"]; ?></td>
    <td><?php echo $row["successful_crosses"]; ?></td>
     <td><?php echo $row["attacks_destroyed"]; ?></td>
      <td><?php echo $row["chances_created"]; ?></td>
       <td><?php echo $row["assists"]; ?></td>
        <td><?php echo $row["goals"]; ?></td>
</tr>
<?php
$i++;
}
?>
</table>
 <?php
}
else{
    echo "The Statistics for this date have not yet been recorded.";
}
}
else{
echo "Please submit a date";
}
?>




<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

 </body>
</html>