<?php

include('../../database_connections/login_connection.php');
require_once("../../database_connections/general_connection.php");
$username =$_SESSION["username"];
$link = connect();
$sql = "SELECT imagepathname FROM tbluserdetails WHERE username ='$username'";
$result =mysqli_query($link,$sql);


if(!isset($_SESSION['username'])) {
header("Location:../../authentication_module/login.php"); 
} 

?>

<!DOCTYPE html>
<html>
 <head>
 <title>View All User Details</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="../../../css/dashboard.php">
<link rel="stylesheet" type="text/css" href="../../../css/index.php">

</head>
<body>

<nav class="navbar navbar-dark bg-dark navbar-expand-sm">
  <p class="navbar-brand" href="#">
<?php echo $_SESSION["username"];?>
  </p>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-list-4" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbar-list-4">
    <ul class="navbar-nav">
        <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <img 

<?php
$i=0;
while($row = mysqli_fetch_array($result)) { 
?>
 src="<?php echo $row["imagepathname"]; ?>" width="100" height="100" class="rounded-circle" >
<?php
$i++;
}
?>

        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="manager.php">Dashboard</a>
          <a class="dropdown-item" href="../../database_connections/login_connection.php?logout_user">Log Out</a>
        </div>
      </li>   
    </ul>
  </div>
</nav>
<h1>Select Date And Matchday Preference</h1>
<form name="regform" action = "squad.php" method="post" onsubmit="validateForm()">
<label for="year">Year:</label>
  <select list="year" name="year">
  <datalist id="year">
<option value="2021">2021</option>
<option value="2022">2022</option> 
<option value="2023">2023</option> 
</datalist>

</select>
<label for="year">Month:</label>
  <select list="month" name="month">
  <datalist id="month">
 <option value="January">January</option>  
<option value="February">February</option> 
<option value="March">March</option>
<option value="April">April</option>
<option value="May">May</option> 
<option value="June">June</option> 
<option value="July">July</option> 
<option value="August">August</option> 
<option value="September">September</option>
<option value="October">October</option> 
<option value="November">November</option> 
<option value="December">December</option>
</datalist>
</select>

<label for="week">week:</label>
  <select list="week" name="week">
  <datalist id="week">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option> 
</datalist>
</select>


<label for="formation">Formation:</label>
  <select list="formation" name="formation">
  <datalist id="formation">
<option value="--">--</option>
<option value="442">4-4-2</option>
</datalist>
</select>
<label for="play_style">Play Style:</label>
  <select list="play_style" name="play_style">
  <datalist id="play_style">
<option value="--">--</option>
<option value="Attack">Attack</option>
<option value="Defend">Defend</option> 
</datalist>
</select>


<button type="submit" name="submit" value="submit" id="submit">Submit</button>
<br>
<br>
<?php 
if (isset($_POST["submit"])){
$year =$_POST["year"];
$month =$_POST["month"];
$week =$_POST["week"];
$formation =$_POST["formation"];
$play_style =$_POST["play_style"];

if ($formation == 442 AND $play_style == "Defend"){

$sql_gk = "SELECT saves FROM tblstatistics WHERE year = $year AND month ='$month'
 AND week = $week AND total >=3 ORDER BY saves DESC LIMIT 1 OFFSET 0";  ;  
$result_gk=mysqli_query($link,$sql_gk);
$row_gk =  mysqli_fetch_array($result_gk);
$id_most_saves = $row_gk[0];
$sql_goalkeeper="SELECT first_name,last_name FROM tbluserdetails 
WHERE id = (SELECT id FROM tblstatistics WHERE saves =$id_most_saves AND total >=3)";
$result_goalkeeper =mysqli_query($link,$sql_goalkeeper);
$row_goalkeeper=  mysqli_fetch_array($result_goalkeeper);

$sql_cb ="SELECT clearances FROM tblstatistics WHERE year = $year AND month ='$month'
 AND week = $week AND total >=3 ORDER BY clearances DESC LIMIT 1 OFFSET 0";   ;  
$result_cb=mysqli_query($link,$sql_cb);
$row_cb =  mysqli_fetch_array($result_cb);
$id_most_clears = $row_cb[0];
$sql_cb1="SELECT first_name,last_name FROM tbluserdetails 
WHERE id = (SELECT id FROM tblstatistics WHERE clearances =$id_most_clears AND total >=3)";
$result_cb1 =mysqli_query($link,$sql_cb1);
$row_cb1=  mysqli_fetch_array($result_cb1);

$sql_cbb = "SELECT successful_tackles FROM tblstatistics WHERE year = $year AND month ='$month'
 AND week = $week AND total >=3 ORDER BY successful_tackles DESC LIMIT 1 OFFSET 0";  ;  
$result_cbb=mysqli_query($link,$sql_cbb);
$row_cbb =  mysqli_fetch_array($result_cbb);
$id_most_tackles = $row_cbb[0];
$sql_cb2="SELECT first_name,last_name FROM tbluserdetails 
WHERE id = (SELECT id FROM tblstatistics WHERE successful_tackles =$id_most_tackles AND total >=3)";
$result_cb2 =mysqli_query($link,$sql_cb2);
$row_cb2=  mysqli_fetch_array($result_cb2);

$sql_rb = "SELECT clearances FROM tblstatistics WHERE year = $year AND month ='$month'
 AND week = $week AND total >=3 ORDER BY clearances DESC LIMIT 1 OFFSET 1";  
$result_rb=mysqli_query($link,$sql_rb);
$row_rb =  mysqli_fetch_array($result_rb);
$id_2ndmost_clears = $row_rb['clearances'];
$sql_rback="SELECT first_name,last_name FROM tbluserdetails 
WHERE id = (SELECT id FROM tblstatistics WHERE clearances =$id_2ndmost_clears AND total >=3)";
$result_rback =mysqli_query($link,$sql_rback);
$row_rback=  mysqli_fetch_array($result_rback);

$sql_lb = "SELECT successful_crosses FROM tblstatistics WHERE year = $year AND month ='$month'
 AND week = $week AND total >=3 ORDER BY successful_crosses DESC LIMIT 1 OFFSET 0";  
$result_lb=mysqli_query($link,$sql_lb);
$row_lb =  mysqli_fetch_array($result_lb);
$id_most_crosses = $row_lb['successful_crosses'];
$sql_lback="SELECT first_name,last_name FROM tbluserdetails 
WHERE id = (SELECT id FROM tblstatistics WHERE successful_crosses =$id_most_crosses AND total >=3)";
$result_lback =mysqli_query($link,$sql_lback);
$row_lback=  mysqli_fetch_array($result_lback);

$sql_lm = "SELECT attacks_destroyed FROM tblstatistics WHERE year = $year AND month ='$month'
 AND week = $week AND total >=3 ORDER BY attacks_destroyed DESC LIMIT 1 OFFSET 3";  
$result_lm=mysqli_query($link,$sql_lm);
$row_lm =  mysqli_fetch_array($result_lm);
$id_4thmost_destroyed = $row_lm['attacks_destroyed'];
$sql_lmid="SELECT first_name,last_name FROM tbluserdetails 
WHERE id = (SELECT id FROM tblstatistics WHERE attacks_destroyed =$id_4thmost_destroyed AND total >=3)";
$result_lmid =mysqli_query($link,$sql_lmid);
$row_lmid=  mysqli_fetch_array($result_lmid);

$sql_cm = "SELECT attacks_destroyed FROM tblstatistics WHERE year = $year AND month ='$month'
 AND week = $week AND total >=3 ORDER BY attacks_destroyed DESC LIMIT 1 OFFSET 0";  
$result_cm=mysqli_query($link,$sql_cm);
$row_cm =  mysqli_fetch_array($result_cm);
$id_most_destroyed = $row_cm['attacks_destroyed'];
$sql_cmid="SELECT first_name,last_name FROM tbluserdetails 
WHERE id = (SELECT id FROM tblstatistics WHERE attacks_destroyed =$id_most_destroyed AND total >=3)";
$result_cmid =mysqli_query($link,$sql_cmid);
$row_cmid=  mysqli_fetch_array($result_cmid);

$sql_cmm = "SELECT attacks_destroyed FROM tblstatistics WHERE year = $year AND month ='$month'
 AND week = $week AND total >=3 ORDER BY attacks_destroyed DESC LIMIT 1 OFFSET 1";  
$result_cmm=mysqli_query($link,$sql_cmm);
$row_cmm =  mysqli_fetch_array($result_cmm);
$id_2ndmost_destroyed = $row_cmm['attacks_destroyed'];
$sql_cmid2="SELECT first_name,last_name FROM tbluserdetails 
WHERE id = (SELECT id FROM tblstatistics WHERE attacks_destroyed =$id_2ndmost_destroyed AND total >=3)";
$result_cmid2 =mysqli_query($link,$sql_cmid2);
$row_cmid2=  mysqli_fetch_array($result_cmid2);

$sql_rm = "SELECT attacks_destroyed FROM tblstatistics WHERE year = $year AND month ='$month'
 AND week = $week AND total >=3 ORDER BY attacks_destroyed DESC LIMIT 1 OFFSET 2";  
$result_rm=mysqli_query($link,$sql_rm);
$row_rm =  mysqli_fetch_array($result_rm);
$id_3rdmost_destroyed = $row_rm['attacks_destroyed'];
$sql_rmid="SELECT first_name,last_name FROM tbluserdetails 
WHERE id = (SELECT id FROM tblstatistics WHERE attacks_destroyed =$id_3rdmost_destroyed AND total >=3)";
$result_rmid =mysqli_query($link,$sql_rmid);
$row_rmid=  mysqli_fetch_array($result_rmid);

$sql_ls = "SELECT chances_created FROM tblstatistics WHERE year = $year AND month ='$month'
 AND week = $week AND total >=3 ORDER BY chances_created DESC LIMIT 1 OFFSET 0";  
$result_ls=mysqli_query($link,$sql_ls);
$row_ls =  mysqli_fetch_array($result_ls);
$id_most_chances_created = $row_ls['chances_created'];
$sql_lstriker="SELECT first_name,last_name FROM tbluserdetails 
WHERE id = (SELECT id FROM tblstatistics WHERE chances_created =$id_most_chances_created AND total >=3)";
$result_lstriker =mysqli_query($link,$sql_lstriker);
$row_lstriker=  mysqli_fetch_array($result_lstriker);

$sql_rs = "SELECT goals FROM tblstatistics WHERE year = $year AND month ='$month'
 AND week = $week AND total >=3 ORDER BY goals DESC LIMIT 1 OFFSET 0";  
$result_rs=mysqli_query($link,$sql_rs);
$row_rs =  mysqli_fetch_array($result_rs);
$id_most_goals = $row_rs['goals'];
$sql_rstriker="SELECT first_name,last_name FROM tbluserdetails 
WHERE id = (SELECT id FROM tblstatistics WHERE goals =$id_most_goals AND total >=3)";
$result_rstriker =mysqli_query($link,$sql_rstriker);
$row_rstriker=  mysqli_fetch_array($result_rstriker);
?>

<h4>Goalkeeper: <?Php echo $row_goalkeeper[0]." ".$row_goalkeeper[1];?></h4>
<br>
<h4>Left Back: <?Php echo $row_lback[0]." ".$row_lback[1];?></h4>
<h4>Centre Back: <?Php echo $row_cb1[0]." ".$row_cb1[1];?></h4>
<h4>Centre Back: <?Php echo $row_cb2[0]." ".$row_cb2[1];?></h4>
<h4>Right Back: <?Php echo $row_rback[0]." ".$row_rback[1];?></h4>
<br>
<h4>Left Mid: <?Php echo $row_lmid[0]." ".$row_lmid[1];?></h4>
<h4>Centre Mid: <?Php echo $row_cmid[0]." ".$row_cmid[1];?></h4>
<h4>Centre Mid: <?Php echo $row_cmid2[0]." ".$row_cmid2[1];?></h4>
<h4>Right Mid: <?Php echo $row_rmid[0]." ".$row_rmid[1];?></h4>
<br>
<h4>Left Striker: <?Php echo $row_lstriker[0]." ".$row_lstriker[1];?></h4>
<h4>Right Striker: <?Php echo $row_rstriker[0]." ".$row_rstriker[1];?></h4>
<?php
}
else if ($formation == 442 AND $play_style == "Attack"){

$sql_gk = "SELECT saves FROM tblstatistics WHERE year = $year AND month ='$month'
 AND week = $week AND total >=3 ORDER BY saves DESC LIMIT 1 OFFSET 0";  ;  
$result_gk=mysqli_query($link,$sql_gk);
$row_gk =  mysqli_fetch_array($result_gk);
$id_most_saves = $row_gk[0];
$sql_goalkeeper="SELECT first_name,last_name FROM tbluserdetails 
WHERE id = (SELECT id FROM tblstatistics WHERE saves =$id_most_saves AND total >=3)";
$result_goalkeeper =mysqli_query($link,$sql_goalkeeper);
$row_goalkeeper=  mysqli_fetch_array($result_goalkeeper);

$sql_cb ="SELECT clearances FROM tblstatistics WHERE year = $year AND month ='$month'
 AND week = $week AND total >=3 ORDER BY clearances DESC LIMIT 1 OFFSET 0";   ;  
$result_cb=mysqli_query($link,$sql_cb);
$row_cb =  mysqli_fetch_array($result_cb);
$id_most_clears = $row_cb[0];
$sql_cb1="SELECT first_name,last_name FROM tbluserdetails 
WHERE id = (SELECT id FROM tblstatistics WHERE clearances =$id_most_clears AND total >=3)";
$result_cb1 =mysqli_query($link,$sql_cb1);
$row_cb1=  mysqli_fetch_array($result_cb1);

$sql_cbb = "SELECT successful_tackles FROM tblstatistics WHERE year = $year AND month ='$month'
 AND week = $week AND total >=3 ORDER BY successful_tackles DESC LIMIT 1 OFFSET 0";  ;  
$result_cbb=mysqli_query($link,$sql_cbb);
$row_cbb =  mysqli_fetch_array($result_cbb);
$id_most_tackles = $row_cbb[0];
$sql_cb2="SELECT first_name,last_name FROM tbluserdetails 
WHERE id = (SELECT id FROM tblstatistics WHERE successful_tackles =$id_most_tackles AND total >=3)";
$result_cb2 =mysqli_query($link,$sql_cb2);
$row_cb2=  mysqli_fetch_array($result_cb2);

$sql_rb = "SELECT successful_crosses FROM tblstatistics WHERE year = $year AND month ='$month'
 AND week = $week AND total >=3 ORDER BY successful_crosses DESC LIMIT 1 OFFSET 1";  
$result_rb=mysqli_query($link,$sql_rb);
$row_rb =  mysqli_fetch_array($result_rb);
$id_2ndmost_successful_crosses = $row_rb['successful_crosses'];
$sql_rback="SELECT first_name,last_name FROM tbluserdetails 
WHERE id = (SELECT id FROM tblstatistics WHERE successful_crosses =$id_2ndmost_successful_crosses AND total >=3)";
$result_rback =mysqli_query($link,$sql_rback);
$row_rback=  mysqli_fetch_array($result_rback);

$sql_lb = "SELECT successful_crosses FROM tblstatistics WHERE year = $year AND month ='$month'
 AND week = $week AND total >=3 ORDER BY successful_crosses DESC LIMIT 1 OFFSET 0";  
$result_lb=mysqli_query($link,$sql_lb);
$row_lb =  mysqli_fetch_array($result_lb);
$id_most_crosses = $row_lb['successful_crosses'];
$sql_lback="SELECT first_name,last_name FROM tbluserdetails 
WHERE id = (SELECT id FROM tblstatistics WHERE successful_crosses =$id_most_crosses AND total >=3)";
$result_lback =mysqli_query($link,$sql_lback);
$row_lback=  mysqli_fetch_array($result_lback);

$sql_lm = "SELECT assists FROM tblstatistics WHERE year = $year AND month ='$month'
 AND week = $week AND total >=3 ORDER BY assists DESC LIMIT 1 OFFSET 0";  
$result_lm=mysqli_query($link,$sql_lm);
$row_lm =  mysqli_fetch_array($result_lm);
$id_most_assists = $row_lm['assists'];
$sql_lmid="SELECT first_name,last_name FROM tbluserdetails 
WHERE id = (SELECT id FROM tblstatistics WHERE assists =$id_most_assists AND total >=3)";
$result_lmid =mysqli_query($link,$sql_lmid);
$row_lmid=  mysqli_fetch_array($result_lmid);

$sql_cm = "SELECT attacks_destroyed FROM tblstatistics WHERE year = $year AND month ='$month'
 AND week = $week AND total >=3 ORDER BY attacks_destroyed DESC LIMIT 1 OFFSET 0";  
$result_cm=mysqli_query($link,$sql_cm);
$row_cm =  mysqli_fetch_array($result_cm);
$id_most_destroyed = $row_cm['attacks_destroyed'];
$sql_cmid="SELECT first_name,last_name FROM tbluserdetails 
WHERE id = (SELECT id FROM tblstatistics WHERE attacks_destroyed =$id_most_destroyed AND total >=3)";
$result_cmid =mysqli_query($link,$sql_cmid);
$row_cmid=  mysqli_fetch_array($result_cmid);

$sql_cmm = "SELECT chances_created FROM tblstatistics WHERE year = $year AND month ='$month'
 AND week = $week AND total >=3 ORDER BY chances_created DESC LIMIT 1 OFFSET 0";  
$result_cmm=mysqli_query($link,$sql_cmm);
$row_cmm =  mysqli_fetch_array($result_cmm);
$id_most_created = $row_cmm['chances_created'];
$sql_cmid2="SELECT first_name,last_name FROM tbluserdetails 
WHERE id = (SELECT id FROM tblstatistics WHERE chances_created =$id_most_created AND total >=3)";
$result_cmid2 =mysqli_query($link,$sql_cmid2);
$row_cmid2=  mysqli_fetch_array($result_cmid2);

$sql_rm = "SELECT assists FROM tblstatistics WHERE year = $year AND month ='$month'
 AND week = $week AND total >=3 ORDER BY assists DESC LIMIT 1 OFFSET 1";  
$result_rm=mysqli_query($link,$sql_rm);
$row_rm =  mysqli_fetch_array($result_rm);
$id_2ndmost_assists = $row_rm['assists'];
$sql_rmid="SELECT first_name,last_name FROM tbluserdetails 
WHERE id = (SELECT id FROM tblstatistics WHERE assists =$id_2ndmost_assists AND total >=3)";
$result_rmid =mysqli_query($link,$sql_rmid);
$row_rmid=  mysqli_fetch_array($result_rmid);

$sql_ls = "SELECT goals FROM tblstatistics WHERE year = $year AND month ='$month'
 AND week = $week AND total >=3 ORDER BY goals DESC LIMIT 1 OFFSET 0";  
$result_ls=mysqli_query($link,$sql_ls);
$row_ls =  mysqli_fetch_array($result_ls);
$id_most_goals= $row_ls['goals'];
$sql_lstriker="SELECT first_name,last_name FROM tbluserdetails 
WHERE id = (SELECT id FROM tblstatistics WHERE goals =$id_most_goals AND total >=3)";
$result_lstriker =mysqli_query($link,$sql_lstriker);
$row_lstriker=  mysqli_fetch_array($result_lstriker);

$sql_rs = "SELECT goals FROM tblstatistics WHERE year = $year AND month ='$month'
 AND week = $week AND total >=3 ORDER BY goals DESC LIMIT 1 OFFSET 1";  
$result_rs=mysqli_query($link,$sql_rs);
$row_rs =  mysqli_fetch_array($result_rs);
$id_2ndmost_goals = $row_rs['goals'];
$sql_rstriker="SELECT first_name,last_name FROM tbluserdetails 
WHERE id = (SELECT id FROM tblstatistics WHERE goals =$id_2ndmost_goals AND total >=3)";
$result_rstriker =mysqli_query($link,$sql_rstriker);
$row_rstriker=  mysqli_fetch_array($result_rstriker);
?>

<h4>Goalkeeper: <?Php echo $row_goalkeeper[0]." ".$row_goalkeeper[1];?></h4>
<br>
<h4>Left Back: <?Php echo $row_lback[0]." ".$row_lback[1];?></h4>
<h4>Centre Back: <?Php echo $row_cb1[0]." ".$row_cb1[1];?></h4>
<h4>Centre Back: <?Php echo $row_cb2[0]." ".$row_cb2[1];?></h4>
<h4>Right Back: <?Php echo $row_rback[0]." ".$row_rback[1];?></h4>
<br>
<h4>Left Mid: <?Php echo $row_lmid[0]." ".$row_lmid[1];?></h4>
<h4>Centre Mid: <?Php echo $row_cmid[0]." ".$row_cmid[1];?></h4>
<h4>Centre Mid: <?Php echo $row_cmid2[0]." ".$row_cmid2[1];?></h4>
<h4>Right Mid: <?Php echo $row_rmid[0]." ".$row_rmid[1];?></h4>
<br>
<h4>Left Striker: <?Php echo $row_lstriker[0]." ".$row_lstriker[1];?></h4>
<h4>Right Striker: <?Php echo $row_rstriker[0]." ".$row_rstriker[1];?></h4>
<?php
}
else{
 echo "Please key in all details";
}
}
else{
 echo "Please enter details";
}
?>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

 </body>
</html>