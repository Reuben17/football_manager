<?php
include_once '../../database_connections/general_connection.php';
$link = connect();
session_start();
$username = $_SESSION["username"];

if( isset($_GET['updateusername']) ){
$new_username = $_GET["username"];
echo $new_username;
$sql = "UPDATE tbluserdetails SET username='$new_username' WHERE username= '$username'";
$result = mysqli_query($link, $sql);
$_SESSION["username"] =$new_username;
header("location:manager.php");
}
if(isset( $_GET["updatepassword"])) {
$password = $_GET["password"];
$hashed_password = password_hash($password, PASSWORD_DEFAULT);
$sql = "UPDATE tbluserdetails SET password='$hashed_password' WHERE username= '$username'";
$result = mysqli_query($link, $sql);
header("location:manager.php");
}

else {
 echo "Error updating record: " . mysqli_error($conn);
}
?>