<?php
require_once("../database_connections/general_connection.php");

if (isset($_POST["register"])){
session_start();
$first_name=$_POST["first_name"];
$last_name =$_POST["last_name"];
$_SESSION["username"] = $_POST["username"];
$username = $_SESSION["username"];
$email =$_POST["email"];
$password =$_POST["password"];
$hashed_password = password_hash($password, PASSWORD_DEFAULT);
$role =$_POST["role"];


$sql = "INSERT INTO tbluserdetails(first_name, last_name, username, email, 
password, role)VALUES('$first_name','$last_name','$username',
'$email','$hashed_password','$role')";

echo setData($sql);
header("location:registration_success.php");

}
?>