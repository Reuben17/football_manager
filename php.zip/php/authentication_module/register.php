<!DOCTYPE html>
<html>
<head>
<meta charset ="utf-8">
<title>Register</title>
<link rel="stylesheet" type="text/css" href="../../css/register.php">
<script type="text/javascript">
function validateForm()
{
  var fn = document.forms["regform"]["first_name"].value;
  var ln = document.forms["regform"]["last_name"].value;
   var u = document.forms["regform"]["username"].value;
  var ea = document.forms["regform"]["email"].value;
  var p = document.forms["regform"]["password"].value;
  var r = document.forms["regform"]["role"].value;

  if (fn == null||fn =="")
  {
 alert("First Name cannot be blank");
 return false;
  }
 else if (ln == null||ln =="")
  {
 alert("Last Name cannot be blank");
 return false;
  }
 else if (u == null||u =="")
  {
 alert("Username cannot be blank");
 return false;
  }
 else if (ea == null||ea =="")
  {
 alert("Email Address cannot be blank");
 return false;
  }
  else if (p == null||p =="")
  {
 alert("Password cannot be blank");
 return false;
  }
  else if (r == null||r =="")
  {
 alert("Role cannot be blank");
 return false;
  }
}
</script>

</head>
<body>

<div class = "divloginandregister">
<div class = "divregister" style="width:500px; margin:0 auto;">
<form name="regform" action = "process_register.php" method="post" onsubmit="validateForm()">
<br>	
<label for="first_name">First Name:</label>
<br>
<input type="text" name="first_name" id="first_name">
<br>	
<label for="last_name">Last Name:</label>
<br>
<input type="text" name="last_name" id="last_name">
<br>
<label for="username">Username:</label>
<br>
<input type="text" name="username" id="username">
<br>  
<label for="email">E-mail Address:</label>
<br>
<input type="email" name="email" id="email">
<br>	
<label for="password">Password:</label>
<br>
<input type="password" id="password"  name="password">
<br>
<label for="role">Role:</label>
  <select list="role" name="role">
  <datalist id="role">
<option value="--">--</option>
<option value="Manager">Manager</option>
<option value="Player">Player</option>
<option value="Administrator">Administrator</option>
</datalist>
</select>
<br>
<button type="submit" name="register" value="register" id="register">Register</button>
<br>
</form>
</div>
</div>


</div>
</body>
</html>